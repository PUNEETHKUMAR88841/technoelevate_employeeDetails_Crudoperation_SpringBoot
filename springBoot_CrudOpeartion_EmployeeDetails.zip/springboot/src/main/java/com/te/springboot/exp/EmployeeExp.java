package com.te.springboot.exp;

public class EmployeeExp extends RuntimeException {
	public EmployeeExp(String msg) {
		super(msg);
		
	}
}
