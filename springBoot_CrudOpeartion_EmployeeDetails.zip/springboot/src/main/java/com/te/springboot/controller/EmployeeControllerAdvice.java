package com.te.springboot.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.te.springboot.exp.EmployeeExp;

@ControllerAdvice
public class EmployeeControllerAdvice extends ResponseEntityExceptionHandler {
	@ExceptionHandler(EmployeeExp.class)
	public String  handleExp(EmployeeExp exp, HttpServletRequest request) {
		request.setAttribute("err", exp.getMessage());
		return "errPage";
		
	}

//	public void handleExp(String string, String string2) {
//		// TODO Auto-generated method stub
//		
//	}
}
